exports.handler = async (event) => {
    const response = event.Records[0].cf.response;
    const request = event.Records[0].cf.request;
    const headers = response.headers;
    
    // Get origin from request
    const origin = request.headers.origin ? request.headers.origin[0].value : '*';
    
    // Add CORS headers
    headers['access-control-allow-origin'] = [{ key: 'Access-Control-Allow-Origin', value: origin }];
    headers['access-control-allow-methods'] = [{ key: 'Access-Control-Allow-Methods', value: 'GET,HEAD,OPTIONS,PUT,PATCH,POST,DELETE' }];
    headers['access-control-allow-headers'] = [{ key: 'Access-Control-Allow-Headers', value: 'Content-Type,Authorization,X-Requested-With' }];
    headers['access-control-max-age'] = [{ key: 'Access-Control-Max-Age', value: '86400' }];
    
    // For OPTIONS requests, ensure 200 status
    if (request.method === 'OPTIONS') {
        response.status = '200';
        response.statusDescription = 'OK';
    }
    
    return response;
};
